from flask import Flask, render_template, url_for, request, send_from_directory
import os
import numpy as np
import cv2
import glob
import tensorflow as tf
from tensorflow import keras
from uuid import uuid4
app = Flask(__name__)
APP_ROOT = os.path.dirname(os.path.abspath(__file__))

@app.route("/")
@app.route("/home")
def index():
    return render_template("home_page.html")

@app.route("/report")
def report():
    ip = request.remote_addr
    return render_template("My_paper.html", user_ip=ip)


@app.route("/upload", methods=['POST'])
def upload():
    target = os.path.join(APP_ROOT, 'static/directory/')
    if not os.path.isdir(target):
        os.mkdir(target)
    #######

    for upload in request.files.getlist("file"):
        i = len(os.listdir(target))
        filename = str(i) + "_" + upload.filename
        global destination
        destination = "/".join([target, filename])
        upload.save(destination)
    return render_template("upload_page.html", image_name = filename)

@app.route('/upload/<filename>')
def send_image(filename):
    return send_from_directory("static/directory/", filename)

@app.route('/history')
def history():
    history = np.load(os.path.join(APP_ROOT, 'static/history.npy')).item()
    target = os.path.join(APP_ROOT, 'static/directory')
    paths = glob.glob(os.path.join(target, '*.*'))
    names =[]
    for key in sorted(history.keys()):
        names.append(key) 
    return render_template("history.html", names = reversed(names), history = history)

@app.route('/predict',methods=['POST'])
def predict():

    target = os.path.join(APP_ROOT, 'static/directory')
    global destination
    image_path = destination
    filename = image_path.split('/')[-1]
    img = cv2.imread(image_path)
    img = cv2.resize(img, (64, 64))
    img = img.reshape(-1, 64,64,3)
    
        
    model = keras.models.load_model('keras_model_06.h5')
    pred = model.predict_classes(img)
    product_id = int(pred[0])
    prob = round(max(max(model.predict(img)))*100, 2)
       
    product_names = np.load(os.path.join(APP_ROOT,'static/product_names.npy')).item()
    product_name = product_names[product_id]
        
    history = np.load(os.path.join(APP_ROOT, 'static/history.npy')).item()
    history.update({filename: ["ID: "+str(product_id), "Name: "+str(product_name), "Probability: "+str(prob)+"%"]})
    if len(history) > 4:
        del history[sorted(history.keys())[0]]
    np.save(os.path.join(APP_ROOT, 'static/history.npy'), history)
              
    sample_dir = os.path.join(APP_ROOT,'static/test')
    sample_paths = glob.glob(os.path.join(sample_dir, '*.*'))
    j = 0;
    samp_name =[]
    for samp in sample_paths:
        if int(samp.split('/')[-1][0:3]) == product_id and j < 3:
            h =  str(samp.split('/')[-1])
            samp_name.append(h)
            j = j+1
    
    return render_template('result_page.html',prediction = product_id,  product_name = product_name, prob = prob,
                           image_name = filename, samp_name = samp_name)


if __name__ == "__main__":
    app.run(port = 4040, debug=True)
    



