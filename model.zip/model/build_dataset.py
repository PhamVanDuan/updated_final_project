""" This module takes image data from data folder and save as in two folder: train and test"""
__author__= 'Pham Van Duan'
__email__ = 'phamvanduan14dt1@gmail.com'
__version__= '0.0.1'

import matplotlib.pyplot as plt
import cv2
import numpy as np
import os
import random
import argparse
import glob
#define input argument
parser = argparse.ArgumentParser()
parser.add_argument("--dataset_dir","-d", help = "path to the dataset dictionary", type = str)
parser.add_argument("--output_dir","-o", help = "path to where storing the outputs", type = str)
parser.add_argument("--split_ratio","-s", help = "split ratio for take training data", type = float)
parser.add_argument("--split_ratio_test","-st", help = "split ratio for take testing data", type = float)
# parser.add_argument("--output_size", help = "size of the output images", type = int, default=64)


# def prepare_data(data_dir, split_ratio):
#     """
#     This function gets image data from data folder, store at in train_data array 
#     and creates a label array with elements is ID of product in train_data array
    
#     Argument:
#     -data_dir: string, path of data folder
#     -split_ratio: float, value for take training data
#     Return:
#     -X_train: array, image data in data folder for training
#     -y_train: array, labels of image data in data folder for training
#     -X_test: array, image data in data folder for testing
#     -y_test: array, labels of image data in data folder for testing
    
#     Raises:
#     -None
#     """
#     all_imgs = []
#     image_paths = glob.glob(os.path.join(data_dir, '*/*.jpg'))
#     # shuffle
#     random.seed(123)
#     random.shuffle(image_paths)
#     all_labels = [int(image_path.split('/')[-2]) for image_path in image_paths]
#     for image_path in image_paths:
#         img_np = cv2.imread(image_path)
#         # preprocessing
#         img_np = cv2.resize(img_np, (32,32))
#         # img_np = cv2.cvtColor(img_np, cv2.COLOR_BGR2GRAY)
#         all_imgs.append(img_np)

#     s = split_ratio   
#     s_val = s + ((1-s)/2.0) 

#     X_train = np.array([all_imgs[:int(s*len(all_imgs))]]).reshape(-1,32*32*3)
#     y_train = np.array([all_labels[:int(s*len(all_labels))]]).reshape(-1,1)

#     X_val = np.array(all_imgs[int(s*len(all_imgs)):int(s_val*len(all_imgs))]).reshape(-1,32*32*3)
#     y_val = np.array(all_imgs[int(s*len(all_labels)):int(s_val*len(all_labels))]).reshape(-1,1)

#     X_test = np.array([all_imgs[int(s_val*len(all_imgs)):]]).reshape(-1,32*32*3)
#     y_test = np.array([all_labels[int(s_val*len(all_labels)):]]).reshape(-1,1)

#     return X_train, y_train, X_val, y_val, X_test, y_test

# if __name__ == "__main__":
#     args = parser.parse_args()
#     print("Take data from image data folder... ")
#     X_train, y_train, X_val, y_val, X_test, y_test = prepare_data(args.dataset_dir, args.split_ratio)
#     np.savez(args.output_dir, X_train = X_train, y_train = y_train,
#              X_val = X_val, y_val = y_val,   
#              X_test =X_test, y_test = y_test)

if __name__ == "__main__":
    args = parser.parse_args()

    dataset_dir = args.dataset_dir
    output_dir = args.output_dir
    split_ratio = args.split_ratio
    split_ratio_test = args.split_ratio_test
#     output_size = args.output_size

    assert os.path.isdir(dataset_dir), "The {} is not a directory".format(dataset_dir)
    if os.path.isdir(output_dir) == False:
        print("Create new folder at {}".format(output_dir))
        os.mkdir(output_dir)

    image_paths = glob.glob(os.path.join(dataset_dir, '*/*.jpg'))
    # .../xyz/asjdlasd.jpg
    random.seed(123)
    random.shuffle(image_paths)
    train_image_paths = image_paths[:int(split_ratio*len(image_paths))]
    test_image_paths = image_paths[int(split_ratio*len(image_paths)): int(split_ratio_test*len(image_paths))]
    val_image_paths = image_paths[int(split_ratio_test*len(image_paths)):]

    # train images
    if os.path.isdir(os.path.join(output_dir, 'train')) == False:
        os.mkdir(os.path.join(output_dir, 'train'))
    for image_path in train_image_paths:
        img = cv2.imread(image_path)
#         resized_img = cv2.resize(img, (output_size, output_size))
        img_name = image_path.split('/')[-2].zfill(3) + '_' + image_path.split('/')[-1]
        cv2.imwrite(os.path.join(output_dir, 'train', img_name), img)


    # test images
    if os.path.isdir(os.path.join(output_dir, 'test')) == False:
        os.mkdir(os.path.join(output_dir, 'test'))
    for image_path in test_image_paths:
        img = cv2.imread(image_path)
#         resized_img = cv2.resize(img, (output_size, output_size))
        img_name = image_path.split('/')[-2].zfill(3) + '_' + image_path.split('/')[-1]
        cv2.imwrite(os.path.join(output_dir, 'test', img_name), img)
        
        
    if os.path.isdir(os.path.join(output_dir, 'val')) == False:
        os.mkdir(os.path.join(output_dir, 'val'))
    for image_path in val_image_paths:
        img = cv2.imread(image_path)
#         resized_img = cv2.resize(img, (output_size, output_size))
        img_name = image_path.split('/')[-2].zfill(3) + '_' + image_path.split('/')[-1]
        cv2.imwrite(os.path.join(output_dir, 'val', img_name), img) 
        
        