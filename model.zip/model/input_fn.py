# Input pipeline.
""" This module takes image data from data folder, preprocessing and save as an array"""
__author__= 'Pham Van Duan'
__email__ = 'phamvanduan14dt1@gmail.com'
__version__= '0.0.1'

import numpy as np
import cv2
import random
import glob
import os

def preprocess_images(image_paths):
    """ 
    This function takes images paths, read image,
    convert BGR image to GRAY image, vectorize to 1D array and store in a array.

    Arguments:
    -image_paths: list of string, all direction of image

    Return:
    -images: array, 1D array of images

    Raises:
    -None
    """
    # resize
    # to grayscale
    # vectorize --> 1D
    images = []
    for img_path in image_paths:
        img = cv2.imread(img_path)
        img = cv2.resize(img, (32,32))
#         img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        images.append(img)
    images = np.array(images).reshape(-1,32,32,3)
    images = np.array(images)
    return images

def input_fn(dataset_path):
    """ 
    This function takes data path of data folder, preprocess all images, takes label of image,
    and store in dictionary of images and its labels.

    Arguments:
    -dataset_path: string, dir of data

    Return:
    -Inputs: dict, dictionary of images and its labels.

    Raises:
    -None
    """

    image_paths = glob.glob(os.path.join(dataset_path, "*.*"))
    random.seed(123)
    random.shuffle(image_paths)
    #preprocessing
    images = preprocess_images(image_paths)
    labels = np.array([int(image_path.split('/')[-1][0:3]) for image_path in image_paths])
    # return inputs
    inputs = {'X': images, 'y': labels}
    return inputs
    